#Name:Ahmed Mohamed ID:000397658
charc=input("Please enter a short message no longer than 30 characters?")
start_position= 0
while(len(charc))<=30:
       start_position =(80 // 2) - (len(charc)//2)
       print(start_position)
       break
print("please try again")

