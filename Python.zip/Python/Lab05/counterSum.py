#Name:Ahmed Mohamed ID:000397658

number= int(input("Please enter a number?"))
total_sum = 0
counter=0
while counter < number:
             counter=counter+1
             total_sum = total_sum+number-counter
print("The total is" , total_sum)
