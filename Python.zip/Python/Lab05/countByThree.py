#Name: Ahmed Mohamed ID:000397658

Number = int(input("Please enter a number between 5 and 15?"))
total_sum1=0
total_sum2=0
total_sum3=0
total_sum4=0
total_sum5=0
total_sum6=0
while Number>=5 or Number<=15:
       Number = int(input("Please enter a second number?"))
       total_sum1=Number + 3
       total_sum2=total_sum1+3
       total_sum3=total_sum2+3
       total_sum4=total_sum3+3
       total_sum5=total_sum4+3
       total_sum6=total_sum5+3
       print(total_sum1,total_sum2,total_sum3,total_sum4, total_sum5,total_sum6)
       break





     
