# This program compares the effect of driving at different speeds 
# on your fuel consumption.  The user will enter the distance of 
# their drive in kilometers and the cost of gas per liter.  The 
# program will report back the cost of doing that drive at
# different speeds.
dist = float(input("How long is your daily drive in Kilometers? "))
cost_per_L = float(input("How much does gas cost per liter? "))
mpg = float(input("What is your car's miles per gallon rating? "))
# 0.6 mile = 1 Kilometer, 1 US gallon = 3.78 L, approximately
# convert miles per gallon to kilometers per liter
mpg2kpl = mpg /0.6 / 3.78
# milage tables start at 55mph, need to convert to kph
cost_per_day = cost_per_L*(dist/mpg2kpl)
cost_at_100 = round( cost_per_day*1.03, 2)
print("\nIf you drive at " + str(60*1.6)+" km/h it will cost $"+\
str(cost_at_100)+" per day")
print("That's $"+str(round(cost_at_100*365.4,2))+" per year.\n")

cost_at_120 = round( cost_per_day*1.23, 2)
print("If you drive at " + str(75*1.6)+" km/h it will cost $"+\
str( cost_at_120)+" per day")
print("That's $"+str(round(cost_at_120*365.4,2))+" per year.\n")
print("That's a difference of " +\
str( round( ( cost_at_120 - cost_at_100 ) * 365.4, 2 ) ) +\
" per year to drive 20 km/h faster." )
# how many minutes to drive dist at 100 kph?
timeToDriveAt100 = dist * ( 60 / 100 )
# how many minutes to drive dist at 120 kph?
time_ToDriveAt120 = dist * ( 60 / 120 )
timeDiff = timeToDriveAt100 - time_ToDriveAt120
print("You save " + str(timeDiff) + " minutes per day.")
