
#Name: Ahmed Mohamed ID:000397658 

user= input("what is your name")
question= print(4*4+4*4+4-4*4)
print(user, "please answer the question")
Answer= input("Your response is")
Python_answer= int(4*4+4*4+4-4*4)
difference=(Answer - Python_answer)
if Answer > difference:
     print("postive")
elif Answer < difference:
     print("negative")
else: print("try again")
Result=(difference%3)*1.6+26
print=("Your score is Result" , Result)


           
