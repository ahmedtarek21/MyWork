#Ahmed Mohamed ID:000397658

tab = "\t"

print("A",tab,"B",tab,"not A OR B",tab,"not A and not B")

A = False
B = False
C = not(A or B)
D = not(A)and not(B)
print(A,tab,B,tab,C,tab,tab,D)

A = True
B = False
C = not(A or B)
D = not(A) and not(B)
print (A,tab,B,tab,C,tab,tab,D)

A = True
B = True
C = not(A or B)
D = not(A) and not(B)
print (A,tab,B,tab,C,tab,tab,D)

A = False
B = True
C = not(A or B)
D = not(A) and not(B)
print (A,tab,B,tab,C,tab,tab,D)
