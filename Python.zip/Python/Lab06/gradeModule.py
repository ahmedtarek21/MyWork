#Ahmed Mohamed ID:000397658



course_name=input("What course are you taking?")

labs_weight=int(input("What is the weight of labs in the course?"))

assignments_weight = int(input("What is the weight of the assignments in the course?"))


lab_grade=float(input("Please enter the grade on lab(enter -1 to end)?"))
count_lab=0
while true:
            if lab_grade == -1 : break
            count_lab=count_lab+1
else:
    lab_grade=float(input("Please enter the grade on lab(enter -1 to end)?"))
    
avg_labs=(lab_grade/count_lab)

total_avg_labs=((labs_weight)*((avg_labs))


assignment_grade = float(input("Please enter the grade on assignment(enter -1 to end)?"))

count_assignment=0
                
while true:
      if assignment_grade==-1 :break
      count_assignment=count_assignment+1
else:  assignment_grade=float(input("Please enter the grade on assignment(enter -1 to end)?"))
                       
avg_assignments=(assignment_grade/count_assignment)
total_avg_assignments=((assignments_weight)*((avg_assignments))

total_avg=(((total_avg_labs)+(total_avg_assignments))//((labs_weight)+(assignments_weight)))
                       
total_avg_grade=total_avg
if   total_avg_grade=>90:
     total_avg_grade="A"
elif total_avg_grade>=75 or total_avg_grade<=90:
     total_avg_grade="B"
elif total_avg_grade>=60 or total_avg_grade<=75:
     total_avg_grade="C"
elif total_avg_grade>=50 or total_avg_grade<=60:
     total_avg_grade="D"
elif total_avg_grade<50:
     total_avg_grade="F"
print("your course name is"course_name"and you have earned an average of"total_avg"which is"total_avg_grade)
