#Name Ahmed Mohamed
#ID   000397658

A= input(" Are you asleep or not?(Y/N)")
   
if A =="Y":
  print("Don't bother about it")
elif A =="N":
     B = input("Is your mom calling? (Y/N)")
if B=="Y":
  print("Answer it")
elif B=="N":
     C= input(" Is it morning?")
if C == "Y":
   print("Don't Answer it")
else: C == "N"
print("Answer it")

       
                
