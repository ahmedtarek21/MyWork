#Ahmed Mohamed ID:000347658

studentrow = input( " what is my row? " )
floatstudentrow = float(studentrow)
studentcol = input( " what is my col ? " )
floatstudentcol = float(studentcol)
mypartrow = input( " what is my partner row? " )
floatmypartrow = float(mypartrow)
mypartcol = input( " what is my partner col? " )
floatmypartcol = float(mypartcol)
distance = (( floatstudentrow - floatmypartrow )**2 + ( floatstudentcol - floatmypartcol )**2)**0.5
print(distance > 3)


